function randomNumber(min,max) {
 return Math.floor(Math.random()*(max-min+1)+min)
}




function getAJAX() {
  $.ajax({
    url: // what goes here?
    dataType: 'jsonp',
    success: function(data) {
      // what goes here?
    }
  })
}
